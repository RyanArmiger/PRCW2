#!/usr/bin/env python
# coding: utf-8

# In[1]:


from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import scipy.io
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import random as rn
from numpy import linalg as LA
from sklearn.model_selection import train_test_split
from scipy import linalg
from sklearn.preprocessing import normalize
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from scipy.io import loadmat
from collections import Counter
from sklearn.cluster import KMeans
import time
get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


import json
with open('feature_data.json', 'r') as f:
    features = json.load(f)

features_ar = np.array(features)

# scaler = StandardScaler()
# scaler.fit(features_ar)
# features_ar = scaler.transform(features_ar)


# In[3]:


train_idxs = loadmat('cuhk03_new_protocol_config_labeled.mat')['train_idx'].flatten()
camIds = loadmat('cuhk03_new_protocol_config_labeled.mat')['camId'].flatten()
filelists = loadmat('cuhk03_new_protocol_config_labeled.mat')['filelist'].flatten()
gallery_idxs = loadmat('cuhk03_new_protocol_config_labeled.mat')['gallery_idx'].flatten()
labels = loadmat('cuhk03_new_protocol_config_labeled.mat')['labels'].flatten()
query_idxs = loadmat('cuhk03_new_protocol_config_labeled.mat')['query_idx'].flatten()

train_idxss = np.subtract(train_idxs, 1)
gallery_idxss = np.subtract(gallery_idxs, 1)
query_idxss = np.subtract(query_idxs, 1)


# In[4]:


camIds_train = camIds[train_idxss]
filelists_train = filelists[train_idxss]
labels_train = labels[train_idxss]
features_train = features_ar[train_idxss]

camIds_gal = camIds[gallery_idxss]
filelists_gal = filelists[gallery_idxss]
labels_gal = labels[gallery_idxss]
features_gal = features_ar[gallery_idxss]

camIds_query = camIds[query_idxss]
filelists_query = filelists[query_idxss]
labels_query = labels[query_idxss]
features_query = features_ar[query_idxss]


# In[5]:


def rankKeval(labels_neigh, label_query):
    contained = False
    for i in range (0, len(labels_neigh)):
        if (labels_neigh[i] == label_query):
            contained = True
    return(contained)


# In[6]:


def ret_NN(knn, query_l, query_f, query_Id, k, s_net):
    n = k + s_net
    neigh = knn.kneighbors([query_f], n, return_distance=False) 
    neigh = neigh[0]
    m = 0
    while m<len(neigh):
        if ((query_l == labels_gal[neigh[m]]) and (query_Id == camIds_gal[neigh[m]])):
            neigh = np.delete(neigh, [m])
            m = m-1
        m = m+1
    m = len(neigh)
    if m>k:
        while m>k:
            neigh = np.delete(neigh, m-1)
            m = len(neigh)       
    labels_neigh = [labels_gal[i] for i in neigh]
    return (labels_neigh)


# In[7]:


def scores_query(ranklist, query_l, instances, k):
    acc = 0
    TP = 0
    FP = 0
    prec = 0
    rec = 0
    
    if rankKeval(ranklist, query_l) == True:
        acc = 1
        
    for i in range (0, k):
        if (ranklist[i] == query_l):
            TP = TP + 1
        else:
            FP = FP +1
    prec = TP/(TP + FP)
    rec = TP/instances
    
    return(acc, prec, rec)


# In[8]:


def scores_k(acc_l, prec_l, rec_l, k, query_n):
    acc_avg = []
    prec_avg = []
    rec_avg = []
    acc_avg.append(sum(acc_l)/query_n)
    prec_avg.append(sum(prec_l)/query_n)
    rec_avg.append(sum(rec_l)/query_n)
    return(acc_avg, prec_avg, rec_avg)


# In[9]:


def average(lst, lstlen):
#     print('lst = ', lst)
#     print('lst[0][1] = ', lst[1][0])
#     print('lstlen = ', lstlen)
    avg = 0
    for i in range(0, lstlen-1):
#         print('i = ', i)
#         print('lst[i][0] = ', lst[i][0])
        avg = avg + lst[i][0]
    avg = avg/lstlen
    return(avg)


# In[10]:


def build_kNN(featurese, labelse, k, s_net):
    nn= k + s_net
    knn = KNeighborsClassifier(n_neighbors=nn, p=2)
    knn.fit(featurese, labelse)
    return(knn)


# In[11]:


def label_instances(labels):
    labels_copy = np.copy(labels)
    set_l = labels_copy.tolist()
    set_l = set(set_l)
    set_l = list(set_l)
    classes_n = len(set_l)
    instances = [0] * 1467
    for i in range(0, classes_n):
        m = 0
        while m<len(labels_copy):
            if (labels_copy[m] == set_l[i]):
                instances[set_l[i]] = instances[set_l[i]] + 1
                labels_copy = np.delete(labels_copy, m, 0)
                m = m - 1
            m = m + 1
    return(instances)


# In[12]:


def do_kNN(featurese_gal, labels_gal, featurese_query, labels_query, camIds_query, k, s_net):
    knn = build_kNN(featurese_gal, labels_gal, k, s_net)
    query_n = len(labels_query)
    instances = label_instances(labels_gal)
    acc = [0] * (query_n * k)
    prec = [0] * (query_n * k)
    rec = [0] * (query_n * k)
    AA = [0] * k
    AR = [0] * k 
    AP = [0] * k
    mAP = [0] * k 
    for i in range (0, query_n):
        query_l = labels_query[i]
        query_f = featurese_query[i]
        query_Id = camIds_query[i]
        neigh = ret_NN(knn, query_l, query_f, query_Id, k, s_net)
        for z in range (0, k):
            ind = i+(z*query_n)
            acc[ind], prec[ind], rec[ind] = scores_query(neigh, query_l, instances[query_l], (k-z))
            neigh.pop()
    for i in range (0, k):
        LB = i*query_n
        UB = (i+1)*query_n
        AA[i], AP[i], AR[i] = scores_k(acc[LB:UB], prec[LB:UB], rec[LB:UB], i+1, query_n)
    mAP = average(AP, k)
    return(AA, AR, AP, mAP)


# In[13]:


AA, AR, AP, mAP = do_kNN(features_gal, labels_gal, features_query, labels_query, camIds_query, 20, 9)


# In[14]:


print('AA = ', AA)
print('AR = ', AR)
print('AP = ', AP)
print('mAP = ', mAP)


# In[67]:


from metric_learn import LMNN

X = features_train
Y = labels_train

lmnn = LMNN(k=4, learn_rate=1e-6)
lmnn.fit(X, Y)


# In[68]:


from metric_learn import NCA

nca = NCA(max_iter=10000)
nca.fit(X, Y)


# In[69]:


from metric_learn import LSML_Supervised

lsml = LSML_Supervised(num_constraints=200)
lsml.fit(X, Y)


# In[70]:


from metric_learn import SDML_Supervised

sdml = SDML_Supervised(num_constraints=50, balance_param=0.5, sparsity_param=0.01)
sdml.fit(X, Y)


# In[74]:


from metric_learn import LFDA

X = features_train
Y = labels_train

lfda = LFDA()
lfda.fit(X, Y)


# In[75]:


from metric_learn import ITML_Supervised

X = features_train
Y = labels_train

itml = ITML_Supervised(num_constraints=200)
itml.fit(X, Y)


# In[76]:


lfda_gal = lfda.transform(features_gal)
lfda_query = lfda.transform(features_query)


# In[77]:


itml_gal = itml.transform(features_gal)
itml_query = itml.transform(features_query)


# In[78]:


lsml_gal = lsml.transform(features_gal)
lsml_query = lsml.transform(features_query)


# In[79]:


sdml_gal = sdml.transform(features_gal)
sdml_query = sdml.transform(features_query)


# In[83]:


nca_gal = nca.transform(features_gal)
nca_query = nca.transform(features_query)


# In[84]:


lmnn_gal = lmnn.transform(features_gal)
lmnn_query = lmnn.transform(features_query)


# In[85]:


AA, AR, AP, mAP = do_kNN(itml_gal, labels_gal, itml_query, labels_query, camIds_query, 20, 9)


# In[86]:


print('AA = ', AA)
print('AR = ', AR)
print('AP = ', AP)
print('mAP = ', mAP)


# In[87]:


AA, AR, AP, mAP = do_kNN(sdml_gal, labels_gal, sdml_query, labels_query, camIds_query, 20, 9)


# In[88]:


print('AA = ', AA)
print('AR = ', AR)
print('AP = ', AP)
print('mAP = ', mAP)
#78.9


# In[89]:


AA, AR, AP, mAP = do_kNN(lsml_gal, labels_gal, lsml_query, labels_query, camIds_query, 20, 9)


# In[90]:


print('AA = ', AA)
print('AR = ', AR)
print('AP = ', AP)
print('mAP = ', mAP)


# In[91]:


AA, AR, AP, mAP = do_kNN(lmnn_gal, labels_gal, lmnn_query, labels_query, camIds_query, 20, 9)


# In[92]:


print('AA = ', AA)
print('AR = ', AR)
print('AP = ', AP)
print('mAP = ', mAP)


# In[93]:


AA, AR, AP, mAP = do_kNN(lfda_gal, labels_gal, lfda_query, labels_query, camIds_query, 20, 9)


# In[94]:


print('AA = ', AA)
print('AR = ', AR)
print('AP = ', AP)
print('mAP = ', mAP)


# In[95]:


AA, AR, AP, mAP = do_kNN(nca_gal, labels_gal, nca_query, labels_query, camIds_query, 20, 9)


# In[96]:


print('AA = ', AA)
print('AR = ', AR)
print('AP = ', AP)
print('mAP = ', mAP)


# In[ ]:




