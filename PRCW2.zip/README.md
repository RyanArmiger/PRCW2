PyVersions contains .py versions of our source
Notebook versions contains Jupyter notebook versions

Included files:
  KNNBaseline: A simple KNN baseline
  DistanceComp: Simple comparison of distance metrics
  SiameseNetwork: SiameseNetwork trained on hard negative pairs
      Ref:
  KNN-actualpoly: Polynomial kernel
  KNN-no-g: Kernels that do not require hyperparameters

To run these files either open the py verison in python or the notebook version in jupyter. They should output accuracies for different ranks.

SiameseNetwork will load pairs from included csv files
